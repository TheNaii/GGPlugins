﻿using System.Threading;
using System.Threading.Tasks;
using Firebase.Auth;

namespace LoLAM.Core.Cloud;

public sealed class FirebaseAuthService : IAuthService
{
    private readonly FirebaseOptions _opts;
    private readonly FirebaseAuthProvider _provider;

    public FirebaseAuthService(FirebaseOptions opts)
    {
        _opts = opts;
        _provider = new FirebaseAuthProvider(new FirebaseConfig(_opts.ApiKey));
    }

    public async Task<AuthSession> RegisterAsync(string email, string password, CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();
        await _provider.CreateUserWithEmailAndPasswordAsync(email, password);
        // Most UX flows register -> login, so we return a logged-in session:
        return await LoginAsync(email, password, ct);
    }

    public async Task<AuthSession> LoginAsync(string email, string password, CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();

        var link = await _provider.SignInWithEmailAndPasswordAsync(email, password);
        link = await link.GetFreshAuthAsync();

        var session = new AuthSession
        {
            Email = email,
            UserId = link.User.LocalId,
            IdToken = link.FirebaseToken,
            RefreshToken = link.RefreshToken
        };

        _sessionStore.Save(session);
        return session;
    }

    public async Task<AuthSession?> TryRestoreSessionAsync(CancellationToken ct = default)
    {
        ct.ThrowIfCancellationRequested();

        var cached = _sessionStore.Load();
        if (cached is null) return null;

        try
        {
            var refreshed = await _provider.RefreshAuthAsync(cached.RefreshToken);

            return new AuthSession
            {
                Email = refreshed.User.Email ?? cached.Email,
                UserId = refreshed.User.LocalId,
                IdToken = refreshed.FirebaseToken,
                RefreshToken = refreshed.RefreshToken
            };
        }
        catch
        {
            // token revoked/expired/etc.
            _sessionStore.Clear();
            return null;
        }
    }

    public async Task SendPasswordResetAsync(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            throw new ArgumentException("Email is required.");

        await _provider.SendPasswordResetEmailAsync(email);
    }
}