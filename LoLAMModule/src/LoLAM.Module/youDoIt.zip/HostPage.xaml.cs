﻿using System.Windows;
using System.Windows.Controls;
using LoLAccountManager;

namespace LoLAM.Module;

public partial class HostPage : Page
{
    public HostPage()
    {
        InitializeComponent();

        var login = new LoginWindow
        {
            Owner = Application.Current.MainWindow // GGLauncher shell window
        };

        var result = login.ShowDialog();
        if (result != true)
        {
            Content = new TextBlock
            {
                Text = "Login cancelled.",
                FontSize = 18,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            return;
        }

        var w = new LoLAccountManager.MainWindow(login.AuthenticatedCloudSync, login.LoggedInEmail);

        RootHost.Content = w.Content;
        w.Content = null;
    }
}