﻿using LoLAM.Core.Cloud;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public interface IAuthSessionStore
{
    void Save(AuthSession session);
    AuthSession? Load();
    void Clear();
}

public sealed class DpapiAuthSessionStore : IAuthSessionStore
{
    private readonly string _path;

    public DpapiAuthSessionStore(string path)
    {
        _path = path;
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
    }

    public void Save(AuthSession session)
    {
        var payload = JsonConvert.SerializeObject(new Persisted
        {
            Email = session.Email,
            UserId = session.UserId,
            RefreshToken = session.RefreshToken
        });

        var bytes = Encoding.UTF8.GetBytes(payload);
        var protectedBytes = ProtectedData.Protect(bytes, optionalEntropy: null, DataProtectionScope.CurrentUser);
        File.WriteAllBytes(_path, protectedBytes);
    }

    public AuthSession? Load()
    {
        if (!File.Exists(_path)) return null;

        var protectedBytes = File.ReadAllBytes(_path);
        var bytes = ProtectedData.Unprotect(protectedBytes, optionalEntropy: null, DataProtectionScope.CurrentUser);
        var json = Encoding.UTF8.GetString(bytes);

        var p = JsonConvert.DeserializeObject<Persisted>(json);
        if (p is null || string.IsNullOrWhiteSpace(p.RefreshToken)) return null;

        return new AuthSession
        {
            Email = p.Email ?? "",
            UserId = p.UserId ?? "",
            RefreshToken = p.RefreshToken ?? ""
            // IdToken will be refreshed on startup
        };
    }

    public void Clear()
    {
        if (File.Exists(_path)) File.Delete(_path);
    }

    private sealed class Persisted
    {
        public string? Email { get; set; }
        public string? UserId { get; set; }
        public string? RefreshToken { get; set; }
    }
}