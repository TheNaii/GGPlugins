﻿namespace LoLAM.Core.Cloud;

public sealed record AuthSession(string Email, string UserId, string IdToken);
public string RefreshToken { get; init; } = "";