﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using LoLAM.Core.Cloud;

namespace LoLAM.Module;

public partial class LoginPage : Page
{
    private readonly ModuleEntry _module;
    private bool _busy;

    public LoginPage(ModuleEntry module)
    {
        InitializeComponent();
        _module = module;

        // Better UX: focus email on open
        Loaded += (_, _) => EmailBox.Focus();
    }

    private async void Login_Click(object sender, RoutedEventArgs e)
        => await AuthFlowAsync(isRegister: false);

    private async void Register_Click(object sender, RoutedEventArgs e)
        => await AuthFlowAsync(isRegister: true);

    // Enter anywhere triggers Login; Shift+Enter does nothing special
    private async void Page_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && !_busy)
        {
            e.Handled = true;
            await AuthFlowAsync(isRegister: false);
        }
    }

    private async Task AuthFlowAsync(bool isRegister)
    {
        if (_busy) return;

        try
        {
            SetBusy(true);
            HideStatus();

            var email = (EmailBox.Text ?? "").Trim();
            var pass = PasswordBox.Password ?? "";

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(pass))
            {
                ShowStatus("Please enter email and password.");
                return;
            }

            if (_module.Auth is null || _module.Store is null || _module.Presence is null)
            {
                ShowStatus("Module services not initialized.");
                return;
            }

            AuthSession session = isRegister
                ? await _module.Auth.RegisterAsync(email, pass)
                : await _module.Auth.LoginAsync(email, pass);

            await _module.Presence.SetOnlineAsync(session);

            var accountsJson = await _module.Store.DownloadAccountsJsonAsync(session);

            NavigationService?.Navigate(new MainPage(_module, session, accountsJson));
        }
        catch (Exception ex)
        {
            // Never show raw Firebase request/response (contains URLs, payloads, etc.)
            ShowStatus(ToFriendlyAuthError(ex));
        }
        finally
        {
            SetBusy(false);
        }
    }

    private async void ForgotPassword_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;

        try
        {
            SetBusy(true);
            HideStatus();

            var email = (EmailBox.Text ?? "").Trim();
            if (string.IsNullOrWhiteSpace(email))
            {
                ShowStatus("Enter your email first.");
                return;
            }

            if (_module.Auth is null)
            {
                ShowStatus("Module services not initialized.");
                return;
            }

            // Requires a method on your auth service (see below)
            await _module.Auth.SendPasswordResetAsync(email);

            // Avoid account enumeration
            ShowStatus("If an account exists for that email, a reset link has been sent.");
        }
        catch (Exception ex)
        {
            ShowStatus(ToFriendlyPasswordResetError(ex));
        }
        finally
        {
            SetBusy(false);
        }
    }

    private void SetBusy(bool busy)
    {
        _busy = busy;

        EmailBox.IsEnabled = !busy;
        PasswordBox.IsEnabled = !busy;
        LoginButton.IsEnabled = !busy;
        RegisterButton.IsEnabled = !busy;
        ForgotPasswordButton.IsEnabled = !busy;

        // Optional: show simple busy hint in status area
        if (busy)
            ShowStatus("Working…");
        else if (StatusText.Text == "Working…")
            HideStatus();
    }

    private void ShowStatus(string message)
    {
        StatusText.Text = message;
        StatusContainer.Visibility = Visibility.Visible;
    }

    private void HideStatus()
    {
        StatusText.Text = "";
        StatusContainer.Visibility = Visibility.Collapsed;
    }

    private static string ToFriendlyAuthError(Exception ex)
    {
        var msg = ex.Message ?? "";

        // FirebaseIdentityToolkit error codes often appear in message
        if (msg.Contains("INVALID_LOGIN_CREDENTIALS", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("INVALID_PASSWORD", StringComparison.OrdinalIgnoreCase) ||
            msg.Contains("EMAIL_NOT_FOUND", StringComparison.OrdinalIgnoreCase))
        {
            return "Incorrect email or password.";
        }

        if (msg.Contains("TOO_MANY_ATTEMPTS_TRY_LATER", StringComparison.OrdinalIgnoreCase))
            return "Too many attempts. Try again later.";

        if (msg.Contains("WEAK_PASSWORD", StringComparison.OrdinalIgnoreCase))
            return "Password is too weak.";

        if (msg.Contains("EMAIL_EXISTS", StringComparison.OrdinalIgnoreCase))
            return "An account with this email already exists.";

        if (msg.Contains("INVALID_EMAIL", StringComparison.OrdinalIgnoreCase))
            return "That email address looks invalid.";

        // Generic fallback
        return "Could not sign in right now. Please try again.";
    }

    private static string ToFriendlyPasswordResetError(Exception ex)
    {
        var msg = ex.Message ?? "";

        if (msg.Contains("INVALID_EMAIL", StringComparison.OrdinalIgnoreCase))
            return "That email address looks invalid.";

        if (msg.Contains("TOO_MANY_ATTEMPTS_TRY_LATER", StringComparison.OrdinalIgnoreCase))
            return "Too many attempts. Try again later.";

        // Generic fallback (don’t reveal whether the email exists)
        return "Could not send reset email right now. Please try again.";
    }
}