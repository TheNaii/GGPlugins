﻿using System.Windows.Controls;
using GGLauncher.ModuleContracts;
using LoLAM.Core.Cloud;

namespace LoLAM.Module;

public sealed class ModuleEntry : IGGLauncherModule
{
    private IModuleHost? _host;

    internal IAuthService? Auth { get; private set; }
    internal ICloudAccountStore? Store { get; private set; }
    internal IPresenceService? Presence { get; private set; }

    public string Id => "lol-account-manager";
    public string DisplayName => "LoL Account Manager"; // remove if your interface doesn't have it

    public void Initialize(IModuleHost host)
    {
        _host = host;

        var opts = new FirebaseOptions(
            ApiKey: "AIzaSyDeAnFmCEZSejefChCer1V42TsMBSzFJPI",
            ProjectId: "lolaccountmanager"
        );

        Auth = new FirebaseAuthService(opts);
        Store = new FirestoreCloudAccountStore(opts);
        Presence = new FirestorePresenceService(opts);
    }

    public Page CreateMainPage()
    {
        return new LoginPage(this);
    }

    public void Dispose()
    {
        // Later: set offline when the module is unloaded (if we have a session)
    }
}